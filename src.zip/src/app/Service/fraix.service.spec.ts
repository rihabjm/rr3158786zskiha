import { TestBed } from '@angular/core/testing';

import { FraixService } from './fraix.service';

describe('FraixService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FraixService = TestBed.get(FraixService);
    expect(service).toBeTruthy();
  });
});
