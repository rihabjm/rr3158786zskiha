import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Config} from '../Utils/Config';
@Injectable({
  providedIn: 'root'
})
export class UploadfileService {
  private url = Config.BASE_URL ;
  private urldetails =this.url+"/api/file/uploadcv";
  private urld =this.url+"/api/file/uploadcertificat" ;


 constructor(private http: HttpClient) { }
    pushFileToStoragecv(file: File , idCategory :number ): Observable<object> {
 const formdata: FormData = new FormData();

    formdata.append('file', file)
    return this.http.post(`${this.urldetails }/${idCategory}`, formdata);
  }

    pushFileToStoragecertificat(file: File , idCategory :number,idsp :number ): Observable<object> {
 const formdata: FormData = new FormData();

    formdata.append('file', file)
    return this.http.post(`${this.urld}/${idCategory}/${idsp}`, formdata);
  }



  getFilesCv(id :number): Observable<any> {
    return this.http.get(this.url+'/api/file/allcv/'+id);
  }
  getFilesCertifcat(id :number): Observable<any> {
    return this.http.get(this.url+'/api/file/allcertificat/'+id);
  }





  getFiles(): Observable<any> {
    return this.http.get(this.url+'/api/file/all');
  }


}
