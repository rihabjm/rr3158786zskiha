import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Utilisateur} from '../Model/utilisateur';
import {JwtHelperService} from '@auth0/angular-jwt';
import {UtilisateurService} from './utilisateur.service';
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
 url = 'http://localhost:9028';
  jwt: string;
  email: string;
  roles: Array<string>;
  user: Utilisateur;
private jwtHelper = new JwtHelperService();
  constructor(private http: HttpClient, private userService: UtilisateurService) {
  }

  login(u: Utilisateur) {
    return this.http.post(this.url + '/login', u, {observe: 'response'});
  }

  getToken() {
    return localStorage.getItem('token');
  }

  saveToken(jwt: string) {
    localStorage.setItem('token', jwt);
    this.jwt = jwt;
    this.parseJWT();
  }


  parseJWT() {
    const jwtHelper = new JwtHelperService();
    const jwtObject = jwtHelper.decodeToken(this.jwt);
    this.email = jwtObject.sub;
    this.roles = jwtObject.roles;
    console.log('after jwt email = ', this.email);
  }

  isAdmin() {
    this.jwt = localStorage.getItem('token');
    this.parseJWT();
    return this.roles.indexOf('ADMIN') >= 0;
  }

  isUser() {
    this.jwt = localStorage.getItem('token');
    this.parseJWT();
    return this.roles.indexOf('USER') >= 0;
  }

  isAuthentified() {
    this.jwt = localStorage.getItem('token');
    this.parseJWT();
    return this.roles && (this.isAdmin() || this.isUser());
  }

  loggedIn() {
    return !!localStorage.getItem('token');
  }

  loggedOut() {
    localStorage.removeItem('token');
    this.email = '';
    this.roles = [];
  }

  getUser(): Promise<Utilisateur> {
    this.jwt = localStorage.getItem('token');
    this.parseJWT();
    return this.userService.findByEmail(this.email).toPromise();
  }
   getUser1(): Utilisateur {
    const token = localStorage.getItem('token');
    const helper = new JwtHelperService();
    const decodedToken = helper.decodeToken(token);
    return decodedToken.user;
  }

 public getRole(): any {
 const decoded =   this.jwtHelper.decodeToken(localStorage.getItem('token'));
 }

}
