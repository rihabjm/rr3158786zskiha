
import { Inscrir} from './inscrir';
import { Formation} from './formation';
export class Session {
  idsession : number  ;
datedebut : Date ;
datefin : Date ;
nombrepartcipant : number ;
inscrirs :Inscrir[]  ;
formation :Formation ;
}
