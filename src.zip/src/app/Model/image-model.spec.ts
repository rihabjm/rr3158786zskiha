import { ImageModel } from './image-model';

describe('ImageModel', () => {
  it('should create an instance', () => {
    expect(new ImageModel()).toBeTruthy();
  });
});
