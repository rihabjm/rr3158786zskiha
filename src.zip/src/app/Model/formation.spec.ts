import { Formation } from './formation';

describe('Formation', () => {
  it('should create an instance', () => {
    expect(new Formation()).toBeTruthy();
  });
});

