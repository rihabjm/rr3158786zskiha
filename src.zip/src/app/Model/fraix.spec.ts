import { Fraix } from './fraix';

describe('Fraix', () => {
  it('should create an instance', () => {
    expect(new Fraix()).toBeTruthy();
  });
});
