import { Session } from './session';

describe('Session', () => {
  it('should create an instance', () => {
    expect(new Session()).toBeTruthy();
  });
});
