import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Promotion} from '../../../Model/promotion';
import {PromotionService} from '../../../Service/promotion.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {NgControl,ValidationErrors } from '@angular/forms';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import {Formation} from '../../../Model/formation';
import {FormationService} from '../../../Service/formation.service';
import {Remise} from '../../../Model/remise';
import {RemiseService} from '../../../Service/remise.service';
@Component({
  selector: 'app-promotion',
  templateUrl: './promotion.component.html',
  styleUrls: ['./promotion.component.scss']
})
export class PromotionComponent implements OnInit {

  constructor(private remiseservice:RemiseService ,private formationservice :FormationService ,private promotionservice :PromotionService,private httpClient: HttpClient ,private _Activatedroute:ActivatedRoute,config: NgbModalConfig, private modalService: NgbModal , private router: Router ,private promotionService: PromotionService) { }
 promotion : Promotion  = new Promotion();
 temp =new Array();
promotions : Promotion[] = new Array();
  ngOnInit() {
   this.getAllPromotion() ;
    this.formationservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    })
  }



/****************ajouter *******************/
open(contentAjout) {
    this.modalService.open(contentAjout);
  }
 messageajout : String ;


  ajouter(promotion :Promotion){
this.promotionservice.save(promotion).subscribe(data => {

if (data.success) {
    this.getAllPromotion();
  this.messageajout ="promotion   ajoutée ";
  } else {
          this.messageajout ="echec  d'ajout ";
}
 console.log(data) }, error => console.log(error));
}



/**********************************************/
private getAllPromotion() {
 this.promotionService.getAll().subscribe(data => {
 this.promotions=data ;
      console.log(this.promotions);
    }, ex => {
      console.log(ex);
    });}

    /*****************  supprmer *************/
    message :String ;

 delete(id: number) {

    this.promotionService.delete(id).subscribe(data => {

if (data.success) {
    this.getAllPromotion();
  this.message ="promotion supprimé ";
  } else {
          this.message ="echec  du suppression ";
}
   }, ex => {

     console.log(ex);
    });
  }

/*******************modif **************************/
  messagemodif :String ;
   promotionmodif : Promotion  = new Promotion();

  openmodif(contentModif , id :number) {

    this.modalService.open(contentModif);
  this.promotionService.getpromotion(id)
      .subscribe(data => {
        console.log(data)
        this.promotionmodif = data;
      }, error => console.log(error));
  }

  private update(promotionmodif:Promotion) {
    this.promotionService.update(promotionmodif).subscribe(
   data => {
if (data.success) {
    this.getAllPromotion();
  this.messagemodif ="Promotion modifié ";
  } else {
          this.messagemodif ="Echec  du modification ";
}
    }, ex => {console.log(ex);
    });
  }

/************** affect formation ***********/
   formation :Formation ;
 id :number ;
   formations : Formation[] = new Array();
   formationselectionne  : Formation[] =new Array();
   promo :Promotion =new Promotion();
   remise :Remise =new Remise();
   affect : number ;
messageaffect :String ;
openpromotion(contentpromotion, id :number){
    this.modalService.open(contentpromotion);
              this.promotionService.getpromotion(id)
      .subscribe(data => {
        console.log(data)
        this.promo = data;

      }, error => console.log(error));
     }

 choisir(formationslct :Formation)
 {
  this.formationselectionne.push(formationslct) ;
  console.log(formationslct);
 }


affecter(remise :Remise)
{

this.affect =0 ;

for(let i=0;i<this.formationselectionne.length ;i++)
{

this.remiseservice.add(remise,this.promo.idpromotion,this.formationselectionne[i].idformation).subscribe(data => {
if (data!=null) {

  this.affect =1 ;
  } else {
          this.affect =0 ;
}
    }, ex => {
      console.log(ex);
    });

    if(this.affect =1)
    {this.messageaffect ="formations affecte  au promotion " ;}
    else {

    this.messageaffect="echec d'affectation";
    }
}
}

}
