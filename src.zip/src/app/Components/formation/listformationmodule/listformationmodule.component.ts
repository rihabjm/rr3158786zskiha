import { Component, OnInit } from '@angular/core';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
import { Router } from '@angular/router';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-listformationmodule',
  templateUrl: './listformationmodule.component.html',
  styleUrls: ['./listformationmodule.component.scss']
})
export class ListformationmoduleComponent implements OnInit {
type :String ;
obj : String ;
message :String ;
constructor(config: NgbModalConfig, private modalService: NgbModal ,private router: Router  ,private formationmoduleserice: FormationmoduleService) { }
 ngOnInit() {
this.getAllmodule();
  }

formations : Formationmodule[] = new Array();



    private getAllmodule() {
 this.formationmoduleserice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

delete(id: number) {

    this.formationmoduleserice.delete(id).subscribe(data => {
      if (data.success) {


      this.getAllmodule();

this.message="Formation supprimer"


} else {
this.message="Erreur de suppresion" ;
  }

    }, ex => {

     console.log(ex);
    });
  }





private getAllformationsBYintitule(obj : String) {
 this.formationmoduleserice.getformationBYintitule(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBydatedebut(obj : String) {
 this.formationmoduleserice.getformationBydatedebut(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBydatefin(obj : String) {
 this.formationmoduleserice.getformationBydatefin(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsyetat(obj : String) {
 this.formationmoduleserice.getformationByetat(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBytype(obj : String) {
 this.formationmoduleserice.getformationBytype(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

private getAllformationsByprix(obj : String) {
 this.formationmoduleserice.getformationByprix(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

/*************************** ajouter ****************/
  formation:Formationmodule=new Formationmodule ;
  messageajout :String ;

   openajout(contentajout){

    this.modalService.open(contentajout);

  }

ajouter(formation :Formationmodule)
{
this.formationmoduleserice.save(this.formation).subscribe( data => {
      this.getAllmodule();
this.messageajout="Formation module ajouté" ;

    }, ex => {
    this.messageajout="Echec d'ajout" ;
      console.log(ex);
    });


           }


/********************** Modofier ***************/

  messagemodif :String ;
   formationmod:Formationmodule=new Formationmodule ;
  openmodif(contentmodif ,id :number) {

    this.modalService.open(contentmodif);
     this.formationmoduleserice.get(id)
      .subscribe(data => {
        console.log(data)
        this.formationmod = data;
      }, error => console.log(error));
  }


  private update(formationmod: Formationmodule) {
    this.formationmoduleserice.update(formationmod).subscribe(
data => {
     this.getAllmodule();
 if (data.success) {

     this.messagemodif ="Formation modifié ";

     } else {
          this.messagemodif ="Echec de modification ";

     }
    }, ex => {console.log(ex);
    });
  }

}
