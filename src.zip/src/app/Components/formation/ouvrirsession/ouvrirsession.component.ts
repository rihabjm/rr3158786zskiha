import { Component, OnInit } from '@angular/core';
import {FormationService} from '../../../Service/formation.service';
import {Formation} from '../../../Model/formation';
import {FormationMetiers} from '../../../Model/formation-metiers';
import {FormationMetiersService} from '../../../Service/formation-metiers.service';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-ouvrirsession',
  templateUrl: './ouvrirsession.component.html',
  styleUrls: ['./ouvrirsession.component.scss']
})
export class OuvrirsessionComponent implements OnInit {

  constructor(private router: Router ,private  formationservice : FormationService , private formationsmetiersservice :FormationMetiersService ,private formationmoduleserice: FormationmoduleService) { }
 ngOnInit() {
this.getAll() ;
  }

formations : Formation[] = new Array();



private getAll() {
 this.formationservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

private getAllformationsmetiers() {
 this.formationsmetiersservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}



    private getAllmodule() {
 this.formationmoduleserice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}






delete(id: number) {

    this.formationservice.delete(id).subscribe(data => {
      if (data.success) {


      this.getAll();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }



private getAllformationsBYintitule(intitule : String) {
 this.formationservice.getformationBYintitule(intitule).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBydatedebut(datedeb : String) {
 this.formationservice.getformationBydatedebut(datedeb).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBydatefin(datefin : String) {
 this.formationservice.getformationBydatefin(datefin).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsyetat(etat : String) {
 this.formationservice.getformationByetat(etat).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


private getAllformationsBytype(type : String) {
 this.formationservice.getformationBytype(type).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

private getAllformationsByprix(prix : String) {
 this.formationservice.getformationByprix(prix).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}
}
