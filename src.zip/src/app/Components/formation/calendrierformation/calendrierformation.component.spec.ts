import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalendrierformationComponent } from './calendrierformation.component';

describe('CalendrierformationComponent', () => {
  let component: CalendrierformationComponent;
  let fixture: ComponentFixture<CalendrierformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalendrierformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalendrierformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
