import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import {ProgrammeKhademni} from '../../../Model/programme-khademni';
import {ProgrammekhdemniService} from '../../../Service/programmekhdemni.service';
import {NgControl,ValidationErrors } from '@angular/forms';

import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-listerprogrammekhdemni',
  templateUrl: './listerprogrammekhdemni.component.html',
  styleUrls: ['./listerprogrammekhdemni.component.scss']
})
export class ListerprogrammekhdemniComponent implements OnInit {
 formations : ProgrammeKhademni[] = new Array();

  constructor(config: NgbModalConfig, private modalService: NgbModal ,   private programme :ProgrammekhdemniService) { }

  ngOnInit() {  this.getAllformation();
  }

  private getAllformation() {
 this.programme.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}
 delete(id: number) {

    this.programme.delete(id).subscribe(data => {
      if (data.success) {


      this.getAllformation();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }


  /************************************* ajouter **************************/
   messageajout :String ;
  formation :ProgrammeKhademni = new ProgrammeKhademni()  ;
  openajout(contentajout) {

    this.modalService.open(contentajout);

  }


ajouter(formation){
this.programme.save(this.formation).subscribe( data => {
if (data.success) {
    this.getAllformation();
  this.messageajout ="formation  ajoutée ";
  } else {
          this.messageajout ="echec d'ajout ";
       }

    });
}

/************************** modifier *************************/
messagemodif :String ;
  formationmod :ProgrammeKhademni = new ProgrammeKhademni()  ;
openmodif(contentmodif,id : number)

{
      this.modalService.open(contentmodif);

  this.programme.get(id)
      .subscribe(data => {
        console.log(data)
        this.formationmod = data;
      }, error => console.log(error));}


  private update(formationmod:ProgrammeKhademni) {
    this.programme.update(formationmod).subscribe(
data => {
  if (data.success) {
    this.getAllformation();
     this.messagemodif ="Formation modifié ";

     } else {
          this.messagemodif ="Echec de modification ";

     }

    }, ex => {console.log(ex);
    });
  }




}

