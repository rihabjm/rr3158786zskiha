import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListerprogrammekhdemniComponent } from './listerprogrammekhdemni.component';

describe('ListerprogrammekhdemniComponent', () => {
  let component: ListerprogrammekhdemniComponent;
  let fixture: ComponentFixture<ListerprogrammekhdemniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListerprogrammekhdemniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListerprogrammekhdemniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
