import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Session} from '../../../Model/Session';
import {SessionService} from '../../../Service/session.service';
import {Seance} from '../../../Model/Seance';
import {SeanceService} from '../../../Service/seance.service';
import {Salle} from '../../../Model/Salle';
import {SalleService} from '../../../Service/salle.service';
import {Inscrir} from '../../../Model/Inscrir';
import {InscrirService} from '../../../Service/inscrir.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import {Fraix} from '../../../Model/Fraix';
import {FraixService} from '../../../Service/fraix.service';
@Component({
  selector: 'app-sessionparformation',
  templateUrl: './sessionparformation.component.html',
  styleUrls: ['./sessionparformation.component.scss']
})
export class SessionparformationComponent implements OnInit {
sceance :Seance =new Seance() ;
  sub;
    id ;
    session :Session =new Session();
    seanceajout :Seance =new Seance();
  listeparticipant: Inscrir[] = new Array();
  listseances :Seance [] = new Array();
salles :Salle []=new Array();
  inscrir :Inscrir=new Inscrir();
  constructor(private fraisservice :FraixService ,  private formateurservice :FormateurService ,  private modalService: NgbModal ,config: NgbModalConfig  , private _Activatedroute:ActivatedRoute, private router: Router,private salleservice :SalleService , private seanceservice :SeanceService ,  private sessionservice :SessionService , private inscrirservice :InscrirService)
  {
   config.backdrop = 'static';
    config.keyboard = false;

  }
formateur: Formateur[] = new Array();
listefraix :Fraix[]=new Array();
seance:Seance=new Seance ;

fraix :Fraix =new Fraix();
fr : Fraix =new Fraix() ;




  open(content) {
    this.modalService.open(content);
  }
 formateurchoisir  :number  ;
  openfraix(fraix , id : number ) {
    this.modalService.open(fraix);
    this.formateurchoisir =id ;
  }

addfraix(fr  :Fraix)
{

this.fraisservice.add(fr, this.id ,this.formateurchoisir).subscribe(data => {

      }, error => console.log(error));


}




  openseance(seance) {
    this.modalService.open(seance);
  }

  ngOnInit() {


      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.sessionservice.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.session = data;
      }, error => console.log(error));

   this.sessionservice.getInscrir(this.id).subscribe(data => {
        console.log(data)
        this.listeparticipant = data;
      }, error => console.log(error));

   this.seanceservice.getseance(this.id).subscribe(data => {
        console.log(data)
        this.listseances = data;
      }, error => console.log(error));




               this.inscrirservice.getSessionParticipant(this.id)
      .subscribe(data => {
        console.log(data)
      }, error => console.log(error));


      });

   this.fraisservice.getbysession(this.id).subscribe(data => {
        console.log(data)
        this.listefraix = data;
      }, error => console.log(error));



      this.salleservice.getAll().subscribe(data => {
        console.log(data)
        this.salles = data;
      }, error => console.log(error));

    this.getAll();





      }


affectparticipant(inscrir :Inscrir)
{
this.sessionservice.addparticipant(inscrir, this.session.idsession).subscribe(data => {

      }, error => console.log(error));

      this.listeparticipant.push(this.inscrir);

}

ajouterseance(sceance :Seance)
{
this.seanceservice.createProduct(sceance,sceance.salle.idsalle,this.id).subscribe(data => {


  }, error => console.log(error));

}
private getAll() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}


}















