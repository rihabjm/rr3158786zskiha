import { NgModule , ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { FormateurRoutingModule } from './formateur-routing.module';
import { AjoutformateurComponent } from './ajoutformateur/ajoutformateur.component';
import { SupprimeformateurComponent } from './supprimeformateur/supprimeformateur.component';
import { ModifierformateurComponent } from './modifierformateur/modifierformateur.component';
import { FormateurComponent } from './formateur/formateur.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule  ,FormBuilder }  from '@angular/forms';
import { DetatilsformateurComponent } from './detatilsformateur/detatilsformateur.component';
import { CalndrierformateurComponent } from './calndrierformateur/calndrierformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
import { Routes, RouterModule } from '@angular/router';
import { AffecteformateurComponent } from './affecteformateur/affecteformateur.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HttpClientModule } from '@angular/common/http';





@NgModule({
  declarations: [AjoutformateurComponent, SupprimeformateurComponent, ModifierformateurComponent, ListformateurComponent, FormateurComponent, DetatilsformateurComponent, CalndrierformateurComponent, CalendrierformateurComponent, AffecteformateurComponent ],
  imports: [
    CommonModule,
    FormateurRoutingModule ,
    NgbModule,FormsModule,
     ReactiveFormsModule  ,
     HttpClientModule ,


NgMultiSelectDropDownModule.forRoot()
]
})
export class FormateurModule { }

