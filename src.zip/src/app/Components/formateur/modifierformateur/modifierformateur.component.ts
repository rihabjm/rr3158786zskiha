import { Component, OnInit } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import {FileService} from '../../../Service/file.service';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ListformateurComponent } from '../listformateur/listformateur.component';

@Component({
  selector: 'app-modifierformateur',
  templateUrl: './modifierformateur.component.html',
  styleUrls: ['./modifierformateur.component.scss']
})
export class ModifierformateurComponent implements OnInit {


message  :String ;
  constructor(private _Activatedroute:ActivatedRoute, private router: Router ,private formateurService: FormateurService ) { }
   sub;
    id ;


     formateur : Formateur ;

formateurs: Formateur[] = new Array();

  ngOnInit() {this.getAll() ;


      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.formateurService.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formateur = data;
      }, error => console.log(error));

      });


  }




private getAll() {
 this.formateurService.getAll().subscribe(data => {
 this.formateurs=data ;
      console.log(this.formateurs);
    }, ex => {
      console.log(ex);
    });}




  private update(formateur:Formateur) {
    this.formateurService.update(formateur).subscribe(
data => {

     if (data.success) { this.getAll();

     this.message ="formateur modifié ";

     } else {
          this.message ="echec de modification ";

     }
    }, ex => {console.log(ex);
    });
  }


}
