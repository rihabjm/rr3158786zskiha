import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupprimesalleComponent } from './supprimesalle.component';

describe('SupprimesalleComponent', () => {
  let component: SupprimesalleComponent;
  let fixture: ComponentFixture<SupprimesalleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupprimesalleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupprimesalleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
