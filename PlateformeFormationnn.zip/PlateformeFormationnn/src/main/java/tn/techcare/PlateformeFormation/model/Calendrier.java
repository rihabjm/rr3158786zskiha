package tn.techcare.PlateformeFormation.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Calender")
public class Calendrier {
 
	
	private int id_date;
	 private Date db_date ;
	 @Id
	 private int id ;
	private int year ;
	private int month ;
	private int day ;
	private String event ;
	
	 public String getEvent() {
	return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDb_date() {
		return db_date;
	}
	public void setDb_date(Date db_date) {
		this.db_date = db_date;
	}
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idformation")
    private Formation formation;
	
	
	public int getId_date() {
		return id_date;
	}
	public void setId_date(int id_date) {
		this.id_date = id_date;
	}
	
	public Formation getFormation() {
		return formation;
	}
	public void setFormation(Formation formation) {
		this.formation = formation;
	}
  
	
	
}
