package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Seannce")
public class Seance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int idseance ;
	 private String heuredeb  ;
	 private String heurefin ;
	 
	private int numeroseance  ;
	private String date ;

	


	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	@JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "idsession")
	    private Session session  ;
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "idasalle")
	    private Salle salle  ;

	public Salle getSalle() {
		return salle;
	}
	public void setSalle(Salle salle) {
		this.salle = salle;
	}
	public int getIdseance() {
		return idseance;
	}
	public void setIdseance(int idseance) {
		this.idseance = idseance;
	}
	public String getHeuredeb() {
		return heuredeb;
	}
	public void setHeuredeb(String heuredeb) {
		this.heuredeb = heuredeb;
	}
	public String getHeurefin() {
		return heurefin;
	}
	public void setHeurefin(String heurefin) {
		this.heurefin = heurefin;
	}
	public int getNumeroseance() {
		return numeroseance;
	}
	public void setNumeroseance(int numeroseance) {
		this.numeroseance = numeroseance;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	
	}
