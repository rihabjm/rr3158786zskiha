package tn.techcare.PlateformeFormation.model;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "promotion")
public class Promotion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idpromotion;
   private String designation ;
   private int 	pourcentage ;
   private String details  ;
  

   @JsonIgnore
	@OneToMany(mappedBy = "promotion", cascade = {CascadeType.ALL})
	private List<Remise> remises ;    
   

public Long getIdpromotion() {
		return idpromotion;
	}
	public void setIdpromotion(Long idpromotion) {
		this.idpromotion = idpromotion;
	}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}

public String getDetails() {
	return details;
}
public void setDetails(String details) {
	this.details = details;
}
public List<Remise> getRemises() {
	return remises;
}
public void setRemises(List<Remise> remises) {
	this.remises = remises;
}
public int getPourcentage() {
	return pourcentage;
}
public void setPourcentage(int pourcentage) {
	this.pourcentage = pourcentage;
}

	
   
}
