package tn.techcare.PlateformeFormation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "khademni")
public class khademni  {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_khademni;	 
	private String intitule;
	private String societe_daccuiel; 
    private String periode;  
  
    public String getSociete_daccuiel() {
		return societe_daccuiel;
	}
	public void setSociete_daccuiel(String societe_daccuiel) {
		this.societe_daccuiel = societe_daccuiel;
	}
	public String getIntitule() {
		return intitule;
	}
	public void setIntitule(String intitule) {
		this.intitule = intitule;
	}
	public int getId_khademni() {
		return id_khademni;
	}
	public void setId_khademni(int id_khademni) {
		this.id_khademni = id_khademni;
	}
	
	public String getPeriode() {
		return periode;
	}
	public void setPeriode(String periode) {
		this.periode = periode;
	}
	
	
	 
}
    
	
	