package tn.techcare.PlateformeFormation.repository;
import java.sql.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.FormationModule;


@Repository
public interface FormationMetiersRepository extends JpaRepository<FormationMetiers, Long> {
	
	List<FormationMetiers> findFormationMetiersByType(String type ) ;
	List<FormationMetiers> findFormationMetiersByEtat(String etat ) ;
	List<FormationMetiers> findFormationMetiersByIntitule(String intitule ) ;
	List<FormationMetiers> findFormationMetiersByDatedebut(Date datedeb ) ;
	List<FormationMetiers> findFormationMetiersByDatefin(Date datefin ) ;
	List<FormationMetiers> findFormationMetiersByPrix(float prix ) ;
	FormationMetiers findFormationMetiersByIdformation(Long id ) ;
   
}
