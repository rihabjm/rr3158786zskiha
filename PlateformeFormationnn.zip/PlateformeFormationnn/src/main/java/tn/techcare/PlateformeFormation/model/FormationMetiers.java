package tn.techcare.PlateformeFormation.model;



import javax.persistence.Entity;
import javax.persistence.Table;



@Entity
@Table(name = "formationMetiers")
public class FormationMetiers extends Formation {


    private String duree ;

	public String getDuree() {
		return duree;
	}

	public void setDuree(String duree) {
		this.duree = duree;
	}

	public FormationMetiers(String duree) {
		super();
		this.duree = duree;
	}

	public FormationMetiers() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
