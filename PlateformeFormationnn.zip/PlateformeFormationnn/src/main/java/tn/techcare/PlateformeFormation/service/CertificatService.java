package tn.techcare.PlateformeFormation.service;

import tn.techcare.PlateformeFormation.model.Certificat;
import tn.techcare.PlateformeFormation.model.Image;

public interface CertificatService {
	public Certificat uploadimageFormateur(Certificat certifciat , long idformateur)  ;
	public Certificat uploadCertificatspecialite(Certificat certifciat , long idspecialite)  ;

}
