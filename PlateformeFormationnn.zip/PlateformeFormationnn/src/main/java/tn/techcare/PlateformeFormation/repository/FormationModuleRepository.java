package tn.techcare.PlateformeFormation.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.FormationModule;


@Repository 
public interface FormationModuleRepository extends JpaRepository<FormationModule, Long> {
     List<FormationModule> findFormationModuleByType(String type ) ;
	List<FormationModule> findFormationModuleByEtat(String etat ) ;
	List<FormationModule> findFormationModuleByIntitule(String intitule ) ;
	List<FormationModule> findFormationModuleByDatedebut(Date datedeb ) ;
	List<FormationModule> findFormationModuleByDatefin(Date datefin ) ;
	List<FormationModule> findFormationModuleByPrix(float prix ) ;
    List<FormationModule> findFormationModuleByNombreheure(int nombreheure ) ;
    List<FormationModule> findFormationModuleBySession(String session ) ;
    FormationModule findFormationModuleByIdformation(Long id ) ;


}
