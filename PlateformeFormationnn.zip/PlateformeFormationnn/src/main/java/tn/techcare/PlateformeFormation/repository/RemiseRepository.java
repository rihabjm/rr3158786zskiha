package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Remise;


public interface RemiseRepository extends JpaRepository<Remise,Long> {

}
