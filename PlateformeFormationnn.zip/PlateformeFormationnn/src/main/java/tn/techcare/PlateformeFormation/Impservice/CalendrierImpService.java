package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Calendrier;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.repository.CalendrierRepository;
import tn.techcare.PlateformeFormation.service.CalendrierService;
@Service 
public class CalendrierImpService implements  CalendrierService  {
   @Autowired
	CalendrierRepository  calendrierepository  ;
	
	@Override
	public List<Calendrier> getCalendrier() {
		LocalDate date =LocalDate.now(); 
		
		List<Calendrier> calendrier = new ArrayList<Calendrier>();
	   int val =20200713; 
		
		calendrier = calendrierepository.findAll() ;  
		
		List<Calendrier> calendrieractuelle = new ArrayList<Calendrier>();
		
		for(int i=0 ;i<calendrier.size();i++)
		{    
			
			for(int j=0 ; j<31 ;j++)
			{
			if(calendrier.get(i).getId()==val+j)	
	
				calendrieractuelle.add(calendrier.get(i)) ;
				
			}
			
			
		}
		
		return calendrieractuelle ;
		
		
	 }

	@Override
	public List<Calendrier> getCalendrierbyFormation(Long id) {
		// TODO Auto-generated method stub
		
		
		List<Calendrier> sessions = new ArrayList<Calendrier>();
		sessions=calendrierepository.findAll();
		List<Calendrier> sessionformation = new ArrayList<Calendrier>();
		for(int i=0;i<sessions.size();i++)
		{  
			if(sessions.get(i).getFormation().getIdformation()==id)
			{
				sessionformation.add(sessions.get(i)) ;}
		}
		
		return sessionformation ;
	}

	@Override
	public Calendrier addevent(String event, int id) {
		 Calendrier cal   = calendrierepository.findCalendrierById(id);
             
		 System.out.println(cal.toString());
    	   cal.setEvent(event);
    	     
    	   calendrierepository.save(cal);
       
		return cal;
 
		
		
	}

																																																																																																																																																																																																			
	
	
}
