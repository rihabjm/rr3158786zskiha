package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Inscrir;

public interface InscrirService {
	public Inscrir AjouterInscrir(Inscrir inscrir);

	public List<Inscrir> getInscrirbySession(long idCategory);
	public  List<Inscrir>  getallInscri ();
}
