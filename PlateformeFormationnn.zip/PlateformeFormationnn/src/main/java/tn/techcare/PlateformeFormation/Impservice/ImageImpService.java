package tn.techcare.PlateformeFormation.Impservice;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.ImageRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.service.ImageService;

@Service
@Transactional
public class ImageImpService implements ImageService {
	@Autowired
	private FormateurRepository  formateurrepoistory;
	
	@Autowired
	private ImageRepository  imagerepoistory;
	
	@Override
	public ImageModel uploadimage(ImageModel image, long idformateur) {
	/*	// TODO Auto-generated method stub
		  Formateur formateur = formateurrepoistory.findFormateurById(idformateur);
          image.setFormateur(formateur);	*/  
	        return imagerepoistory.save(image);
	}

}
