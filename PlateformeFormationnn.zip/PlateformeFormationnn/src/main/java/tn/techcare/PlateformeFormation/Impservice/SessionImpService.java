package tn.techcare.PlateformeFormation.Impservice;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.Inscrir;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.repository.FormationRepository;
import tn.techcare.PlateformeFormation.repository.InscrirRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.service.SessionService;
@Service
@Transactional
public class SessionImpService implements SessionService  {
      
	@Autowired
	private SessionRepository  sessionrepoistory;
	@Autowired
	private FormationRepository formationrepository ;
	@Autowired
	private InscrirRepository inscrirrepository ;
	
	
	@Override
	public MessageReponse AjouterSession( Session sessionn1) {
		/*for(int i=0;i<sessionn1.getParticipants().size();i++)
		{
			particpantrepository.save(sessionn1.getParticipants().get(i));
		}*/
	
		sessionrepoistory.save(sessionn1) ;
   return new MessageReponse(true, sessionn1.getIdsession()+ "session est ajouter ") ;
	}

	@Override
	public List<Session> getAllSession() {
		// TODO Auto-generated method stub
		return  sessionrepoistory.findAll();
	}

	@Override
	public MessageReponse ModifierSession(Session sessionn1) {
		Session	 sessionn2 = sessionrepoistory.findSessionByIdsession(sessionn1.getIdsession()) ;
		if(sessionn2== null) {
		return new MessageReponse(false, "erreur , session  introuvable");
		}
		sessionrepoistory.save(sessionn1);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}

	@Override
	public MessageReponse SupprimerSession(Long id_session) {
		Session session = sessionrepoistory.findById(id_session).orElse(null) ;
		if(session== null) {
		return new MessageReponse(false, "erreur , Session  introuvable");
		}
		sessionrepoistory.delete(session);
		return new MessageReponse(true, "operation delete effectue avec succes");
	}

	@Override
	public Session AjouterSession(Session session, Long idformation) {
		// TODO Auto-generated method stub
		  Formation formation = formationrepository.findFormationByIdformation(idformation) ;
            session.setFormation(formation);		  
	        return sessionrepoistory.save(session);
	}

	@Override
	public Session getSessionbyId(Long id) {
		// TODO Auto-generated method stub
	return	sessionrepoistory.findSessionByIdsession(id) ;
	}

	@Override
	public List<Session> getsessionbyformation(long idCategory) {
		// TODO Auto-generated method stub
		List<Session> sessions = new ArrayList<Session>();
		sessions=sessionrepoistory.findAll();
		List<Session> sessionformation = new ArrayList<Session>();
		for(int i=0;i<sessions.size();i++)
		{  
			if(sessions.get(i).getFormation().getIdformation()==idCategory)
			{
				sessionformation.add(sessions.get(i)) ;}
		}
		
		return sessionformation ;
	}

	@Override
	public MessageReponse AjouterParticipantSession(Inscrir inscrir, Long idsession) {
		// TODO Auto-generated method stub
	
		
		Session session = sessionrepoistory.findById(idsession).orElse(null) ;
		if(session== null) {
		return new MessageReponse(false, "erreur , Session  introuvable");
		}
		if(session.getNombrepartcipant()<=10)
		{
			inscrirrepository.save(inscrir) ;
		session.getInscrirs().add(inscrir) ;
		int n= session.getNombrepartcipant()+1 ;
		session.setNombrepartcipant(n);
		sessionrepoistory.save(session) ;
		return new MessageReponse(true, "operation  effectue avec succes");}
		return new MessageReponse(false, "erreur");
		
	}

	@Override
	public List<Inscrir> getinscrirbysession(long idsession) {
		// TODO Auto-generated method stub
		List<Session> sessions = new ArrayList<Session>();
		sessions=sessionrepoistory.findAll();
		List<Inscrir> inscrirsession = new ArrayList<Inscrir>();
		for(int i=0;i<sessions.size();i++)
		{
			if(sessions.get(i).getIdsession()==idsession)
			{
				inscrirsession=sessions.get(i).getInscrirs() ;
				
			}
			
		}
		
		return inscrirsession;
	}



}
