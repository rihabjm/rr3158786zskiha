package tn.techcare.PlateformeFormation.Impservice;

import org.springframework.beans.factory.annotation.Autowired;

import tn.techcare.PlateformeFormation.model.Role;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.repository.RoleRepository;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.service.AccountService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
    private UtilisateurRepository userRepository ;
@Autowired
    private RoleRepository roleRepository ;
@Autowired
private BCryptPasswordEncoder bCryptPasswordEncoder ;
	
	
	@Override
	public Utilisateur saveUser(Utilisateur user) {
		// TODO Auto-generated method stub
		  Utilisateur us = userRepository.findByLogin(user.getLogin());
	        System.out.println("lowwweeellll");
	        if(us!=null) throw new RuntimeException("User already exist");
	        System.out.println("theeeniiiii");
	        user.setMdp(bCryptPasswordEncoder.encode(user.getMdp()));
	        System.out.println("theeeleethhhh");
	        Role role = roleRepository.findByRoleName("USER");
	 	   user.setRole(role) ;
	 	 userRepository.save(user);
	        System.out.println("eeraaabaaaaaa");
	
	      
	    	   System.out.println("elkhamsa");
	     
	    	   
	    	  
	        return user ;
	}

	@Override
	public Role saveRole(Role role) {
		// TODO Auto-generated method stub
		 return roleRepository.save(role);	}

	@Override
	public Utilisateur loadUserByEmail(String email) {
		// TODO Auto-generated method stub
	    return userRepository.findByLogin(email);	}

	@Override
	public void addRoleToUser(String Email, String roleName) {
		// TODO Auto-generated method stub
		 Utilisateur user = userRepository.findByLogin(Email);
	        Role role = roleRepository.findByRoleName(roleName);
	   user.setRole(role) ;
	   
	}

}
