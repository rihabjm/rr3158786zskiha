package tn.techcare.PlateformeFormation.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import tn.techcare.PlateformeFormation.model.CV;
import tn.techcare.PlateformeFormation.model.Certificat;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.service.CertificatService;
import tn.techcare.PlateformeFormation.repository.CertificatRepository ;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.SpecialiteRepository;
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CertificatController {
	@Autowired
   CertificatRepository CertificatRepository;
	 
	@Autowired
	FormateurRepository formateurRepository;
	
	@Autowired
	SpecialiteRepository specialiteRepository;
	
	
	
	  @Autowired
	  CertificatService certificatservice;
	 
	  
	    @PostMapping("/uploadcertificatformateur/{idCategory}")
	    public BodyBuilder uplaodcertificatformateur(@RequestParam("imageFile") MultipartFile file ,@PathVariable("idCategory") long idformateur) throws IOException {
	 
	        System.out.println("Original Image Byte Size - " + file.getBytes().length);
	 
	        Certificat  certificat = new Certificat(file.getOriginalFilename(), file.getContentType(),
	 
	                compressBytes(file.getBytes()));

	        certificatservice.uploadimageFormateur(certificat, idformateur);
	        return ResponseEntity.status(HttpStatus.OK);
	 
	    }
	    
	    

	    
	    
	    
	    
	    
	    
	 
	    @PostMapping("/uploadcertificatspecialite/{idCategory}")
	    public BodyBuilder uplaodcertificatspecialite(@RequestParam("imageFile") MultipartFile file ,@PathVariable("idCategory") long idspecialite) throws IOException {
	 
	        System.out.println("Original Image Byte Size - " + file.getBytes().length);
	 
	        Certificat  certificat = new Certificat(file.getOriginalFilename(), file.getContentType(),
	 
	                compressBytes(file.getBytes()));

	        certificatservice.uploadCertificatspecialite(certificat, idspecialite);
	        return ResponseEntity.status(HttpStatus.OK);
	 
	    }
	    
	    
	   /* @GetMapping(path = { "/get/{imageName}" })
	 
	    public ImageModel getImage(@PathVariable("imageName") String imageName) throws IOException {
	 
	        final Optional<ImageModel> retrievedImage = imageRepository.findByName(imageName);
	 
	        ImageModel img = new ImageModel(retrievedImage.get().getName(), retrievedImage.get().getType(),
	 
	                decompressBytes(retrievedImage.get().getPicByte()));
	 
	        return img;
	 
	    }*/
	 
	    public static byte[] compressBytes(byte[] data) {
	 
	        Deflater deflater = new Deflater();
	 
	        deflater.setInput(data);
	 
	        deflater.finish();
	 
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
	 
	        byte[] buffer = new byte[1024];
	 
	        while (!deflater.finished()) {
	 
	            int count = deflater.deflate(buffer);
	 
	            outputStream.write(buffer, 0, count);
	 
	        }
	 
	        try {
	 
	            outputStream.close();
	 
	        } catch (IOException e) {
	  
	        }
	 
	        System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);
	 
	        return outputStream.toByteArray();
	 
	    }
	 
	    public static byte[] decompressBytes(byte[] data) {
	 
	        Inflater inflater = new Inflater();
	 
	        inflater.setInput(data);
	 
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
	 
	        byte[] buffer = new byte[90240];
	 
	        try {
	 
	            while (!inflater.finished()) {
	 
	                int count = inflater.inflate(buffer);
	 
	                outputStream.write(buffer, 0, count);
	 
	            }
	 
	            outputStream.close();
	 
	        } catch (IOException ioe) {
	 
	        } catch (DataFormatException e) {
	 
	        }
	 
	        return outputStream.toByteArray();
	 
	    }


}
