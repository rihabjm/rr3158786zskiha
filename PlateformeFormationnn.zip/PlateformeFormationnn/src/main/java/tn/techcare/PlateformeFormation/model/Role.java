package tn.techcare.PlateformeFormation.model;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Role {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id ;
	    private String roleName ;

	    public Role(String roleName) {
	        this.roleName = roleName;
	        
	        
	    }
		@JsonIgnore
		@OneToMany(mappedBy = "role", cascade = {CascadeType.MERGE})
		private List<Utilisateur> utilisateur ;

		
		
	    public List<Utilisateur> getUtilisateur() {
			return utilisateur;
		}

		public void setUtilisateur(List<Utilisateur> utilisateur) {
			this.utilisateur = utilisateur;
		}

		public Role() {
	    }

	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getRoleName() {
	        return roleName;
	    }

	    public void setRoleName(String roleName) {
	        this.roleName = roleName;
	    }
}
