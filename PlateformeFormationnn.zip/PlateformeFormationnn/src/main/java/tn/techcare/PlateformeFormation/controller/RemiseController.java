package tn.techcare.PlateformeFormation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Remise;
import tn.techcare.PlateformeFormation.service.RemiseService;

@CrossOrigin("*")
@RestController
@RequestMapping("/remise") 
public class RemiseController {
	@Autowired
	private  RemiseService remiseservice  ;
	
	@PostMapping("/add/{idCategory}/{id}")
	public MessageReponse ajouterremise (@RequestBody Remise remise ,@PathVariable("idCategory")long  idpromotion ,@PathVariable("id") long idformation){
	    
		return remiseservice.Ajouterremise(remise ,idpromotion,idformation);
	}
	
	
	
	
}
