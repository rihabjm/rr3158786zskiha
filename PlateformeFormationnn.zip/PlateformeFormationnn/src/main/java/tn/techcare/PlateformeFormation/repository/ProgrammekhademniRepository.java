package tn.techcare.PlateformeFormation.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.Programmekhademni;
import tn.techcare.PlateformeFormation.model.khademni;

@Repository
public interface ProgrammekhademniRepository  extends JpaRepository<Programmekhademni,Long> {
	Programmekhademni findProgrammekhademniByIdformation(Long id ) ;
	   List<Programmekhademni> findProgrammekhademniByType(String type ) ;
		List<Programmekhademni> findProgrammekhademniByEtat(String etat ) ;
		List<Programmekhademni> findProgrammekhademniByIntitule(String intitule ) ;
		List<Programmekhademni> findProgrammekhademniByDatedebut(Date datedeb ) ;
		List<Programmekhademni> findProgrammekhademniByDatefin(Date datefin ) ;
		List<Programmekhademni> findProgrammekhademnieByPrix(float prix ) ;
}
