package tn.techcare.PlateformeFormation;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.service.AccountService;
import tn.techcare.PlateformeFormation.service.UtilisateurService;


@SpringBootApplication(exclude = {ErrorMvcAutoConfiguration.class})
public class PlateformeFormationApplication implements CommandLineRunner {
	 @Autowired
	 private AccountService accountService;
	public static void main(String[] args) {
		SpringApplication.run(PlateformeFormationApplication.class, args);
	}
	   @Bean
	    BCryptPasswordEncoder getBCPE ()
	    {
	        return new  BCryptPasswordEncoder() ;
	    }
	   
	
	@Override
	   public void run(String... args) throws Exception {
			// TODO Auto-generated method stub
	 /*Utilisateur formateur = new Utilisateur();
		      formateur.setAdresse("51 bv ali trad montfleury");	
	      formateur.setLogin("achref@gmail.com");
	      formateur.setNom("achref");   
	      formateur.setMdp("admin"); 
	      accountService.saveUser(formateur); */

		      
		
		}
		
	
	   

}
