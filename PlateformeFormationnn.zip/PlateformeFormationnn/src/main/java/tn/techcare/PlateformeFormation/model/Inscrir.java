package tn.techcare.PlateformeFormation.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Inscrir")
public class Inscrir extends Utilisateur {
   
	
	

	public Inscrir() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Inscrir(Long id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked, ImageModel image) {
		super(id, nom, prenom, adresse, telephone, login, mdp, dateNAisse, sexe, gmail, facebook, linked, image);
		// TODO Auto-generated constructor stub
	}

	public Inscrir(String login, String mdp) {
		super(login, mdp);
		// TODO Auto-generated constructor stub
	}


	
	 
	 
	 
}
