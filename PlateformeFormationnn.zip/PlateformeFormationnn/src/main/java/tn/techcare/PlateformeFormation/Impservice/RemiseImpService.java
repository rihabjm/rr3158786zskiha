package tn.techcare.PlateformeFormation.Impservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Promotion;
import tn.techcare.PlateformeFormation.model.Remise;
import tn.techcare.PlateformeFormation.repository.FormationRepository;
import tn.techcare.PlateformeFormation.repository.PromotionRepository;
import tn.techcare.PlateformeFormation.repository.RemiseRepository;
import tn.techcare.PlateformeFormation.service.RemiseService;

@Service
public class RemiseImpService implements RemiseService {

	@Autowired 
	public RemiseRepository remiserepository ;
	@Autowired 
	public FormationRepository formationrep ;
	@Autowired 
	public PromotionRepository promotionrepository ;
	
	@Override
	public MessageReponse Ajouterremise(Remise remise ,Long  idpromotion ,Long idformation) {
		// TODO Auto-generated method stub
		
	Optional<Formation> f= formationrep.findById(idformation) ;
	
	Optional<Promotion> p= promotionrepository.findById(idpromotion) ;
	
    remise.setFormation(f.get());
    remise.setPromotion(p.get());
	
	  remiserepository.save(remise);
	  return new MessageReponse(true, "ajouter") ;}

}
