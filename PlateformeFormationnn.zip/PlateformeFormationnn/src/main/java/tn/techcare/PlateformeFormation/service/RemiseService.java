package tn.techcare.PlateformeFormation.service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Remise;

public interface RemiseService {
    public MessageReponse Ajouterremise (Remise remise ,Long  idpromotion ,Long idformation ) ;

}
