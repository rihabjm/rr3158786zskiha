package tn.techcare.PlateformeFormation.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.techcare.PlateformeFormation.model.Certificat;

public interface CertificatRepository extends JpaRepository<Certificat, Long>  {
    Optional<Certificat> findByName(String name);

}
