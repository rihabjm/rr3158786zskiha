package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.khademni;

public interface khademniRepository  extends JpaRepository<khademni,Integer>{

}
