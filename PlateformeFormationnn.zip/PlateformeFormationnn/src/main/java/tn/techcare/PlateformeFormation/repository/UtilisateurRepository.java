package tn.techcare.PlateformeFormation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Utilisateur;

@Repository
public interface UtilisateurRepository extends JpaRepository<Utilisateur, Long> {
	
	Utilisateur  findByLogin(String login);

	Utilisateur  findByLoginAndId(String login , Long id);
    @Query(value = "SELECT u.* FROM `user` u,`user_roles` ur,`role` r WHERE r.id=ur.roles_id and ur.user_id_user=u.id_user and r.role_name = ?", nativeQuery = true)
    List<Utilisateur> findUsers(String type);


}
