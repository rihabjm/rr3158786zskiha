package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.khademni;
public interface KhademniService {
	 public MessageReponse Ajouterkhademni (khademni khademni) ;
	  public List<khademni> getAllkhademni();
     public MessageReponse Modifierkhademni(khademni khademni) ;
	  public MessageReponse Supprimerkhademni(int id);
}
