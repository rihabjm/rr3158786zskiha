package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

 
@Entity
@Table(name = "formateur")
public class Formateur  extends Utilisateur {
 

	
		
	  
	  @JsonIgnore
	  @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	    @JoinColumn(name = "id_f")
	    @JsonIgnoreProperties(value = {"certificat"}, allowSetters = true)
	    private List<Certificat> certificats ;
	  
	  @ManyToMany(fetch = FetchType.EAGER)
	    private Collection<specialiite> specialites = new ArrayList<>();

	  
	  @OneToOne(fetch = FetchType.LAZY,
	            cascade =  CascadeType.ALL,
	            mappedBy = "formateur")
	    private Image image;
	
	   @JsonIgnore
			@OneToMany(mappedBy = "formateur", cascade = {CascadeType.ALL})
			private List<fraispayement> fraix ;
			
			
			
			@JsonIgnore
	  @OneToOne(fetch = FetchType.LAZY,
			  cascade = {CascadeType.ALL},
	            mappedBy = "formateur")
	    private CV cv;
	  

	    
	   

	public Collection<specialiite> getSpecialites() {
		return specialites;
	}

	public void setSpecialites(Collection<specialiite> specialites) {
		this.specialites = specialites;
	}

	public void setCv(CV cv) {
		this.cv = cv;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
  





	public List<fraispayement> getFraix() {
		return fraix;
	}

	public void setFraix(List<fraispayement> fraix) {
		this.fraix = fraix;
	}

	public List<Certificat> getCertificats() {
		return certificats;
	}

	public void setCertificats(List<Certificat> certificats) {
		this.certificats = certificats;
	}

	public CV getCv() {
		return cv;
	}

	public Formateur() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Formateur(Long id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked, ImageModel image) {
		super(id, nom, prenom, adresse, telephone, login, mdp, dateNAisse, sexe, gmail, facebook, linked, image);
		// TODO Auto-generated constructor stub
	}




	
}
