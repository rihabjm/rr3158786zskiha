package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.Image;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.FormationRepository;
import tn.techcare.PlateformeFormation.repository.ImgRepository;
import tn.techcare.PlateformeFormation.service.ImgService;
@Service
public class ImgImpService  implements ImgService {

	@Autowired
	private FormateurRepository  formateurrepoistory;
	
	@Autowired
	private FormationRepository  formationrepoistory;
	
	@Autowired
	private ImgRepository  imagerepoistory;
	
	
	@Override
	public Image uploadimageFormateur(Image image, long idformateur) {
		// TODO Auto-generated method stub
		 Formateur formateur = formateurrepoistory.findFormateurById(idformateur);
         image.setFormateur(formateur);	  
	        return imagerepoistory.save(image);	}

	@Override
	public Image uploadimageFormation(Image image, long idformation) {
		// TODO Auto-generated method stub
		 Formation formation = formationrepoistory.findFormationByIdformation(idformation);
         image.setFormation(formation);	  
	        return imagerepoistory.save(image);	}

	@Override
	public ImageModel getImageFormateur(long idformateur) {
		// TODO Auto-generated method stub
     List<Image>  listimage =imagerepoistory.findAll() ;
     Image retrievedImage = null;

     for(int i=0 ; i<listimage.size() ; i++)
     {
    	 
    	 if(listimage.get(i).getFormateur().getId()==idformateur )
    	 {
    		 
    		  retrievedImage = listimage.get(i) ;
         }
    }
   	 
     return retrievedImage ; 
	
	}

	@Override
	public Image getImageFormation(long idformation) {
		// TODO Auto-generated method stub
	     List<Image>  listimage =imagerepoistory.findAll() ;
	     Image retrievedImage = null;

	     for(int i=0 ; i<listimage.size() ; i++)
	     {
	    	 
	    	 if(listimage.get(i).getFormation().getIdformation()==idformation )
	    	 {
	    		 
	    		  retrievedImage = listimage.get(i) ;
	         }
	    }
	   	 
	     return retrievedImage ; 
	}

}
