package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.specialiite;

public interface SpecialiteService {
    public MessageReponse AjouterSpecialite (specialiite specialite) ;
	   public List<specialiite> getAllSpecilite();
	   
	   public  specialiite getspecialiteById(long id) ;
}
