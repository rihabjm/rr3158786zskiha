package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.entites.PasswordDto;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.service.UtilisateurService;


@Service
public class UtilisateurImpService  implements UtilisateurService{
	@Autowired
	private UtilisateurRepository userRepository;



	@Override
	public Utilisateur findById(Long id) {
		// TODO Auto-generated method stub

		return userRepository.findById(id).orElse(null);	}

	@Override
	public Utilisateur findByEmail(String email) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				return userRepository.findByLogin(email);	}

    @Override
    public List<Utilisateur> getAllUsers() {
        return userRepository.findAll();
    }
  
 
 
    public Utilisateur addUser(Utilisateur user) {
        return userRepository.saveAndFlush(user);
    }
    @Override
    public List<Utilisateur> getTypeUsers(String type) {
        // TODO Auto-generated method stub
        return userRepository.findUsers(type);
    }

    public Utilisateur getUserByEmail(String email) {
        return userRepository.findByLogin(email);
    }

	@Override
	public Utilisateur getUserById(long id) {
		// TODO Auto-generated method stub
        return userRepository.findById(id).get();
	}

	@Override
	public void updateUser(@Valid Utilisateur userDetails, long id) {
		// TODO Auto-generated method stub
    	Utilisateur user = userRepository.findById(id).get();
        user.setDateNAisse(userDetails.getDateNAisse());
        user.setLogin(userDetails.getLogin());
        user.setNom(userDetails.getNom());
        user.setPrenom(userDetails.getPrenom());
        user.setSexe(userDetails.getSexe());
        user.setMdp(userDetails.getMdp());
        user.setTelephone(userDetails.getTelephone());
        user.setAdresse(userDetails.getAdresse());
        userRepository.saveAndFlush(user);
		
	}

	@Override
	public void deleteUser(long id) {
		// TODO Auto-generated method stub
		  userRepository.deleteById(id);
		
	}

	
	
}
